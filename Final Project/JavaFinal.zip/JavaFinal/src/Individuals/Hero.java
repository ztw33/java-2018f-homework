package Individuals;

import Formations.BattleField;
import Formations.Coordinates;
import Game.GameThread;
import javafx.geometry.Pos;

public class Hero extends Individual{
    public Hero() {
        super();
        MyStance = 1;
    }



}
