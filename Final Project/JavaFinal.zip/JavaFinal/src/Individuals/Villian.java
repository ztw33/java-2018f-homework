package Individuals;

import Formations.BattleField;
import Formations.Coordinates;

public class Villian extends Individual {

    public Villian() {
        super();
        MyStance = 2;
    }


}